﻿using System;

namespace Overloading
{
    public class Tour
    {
        public string TourNo;
        public string TourName;
        public string TourPlaceName;
        public Tour(string M)
        {
            TourNo = M;
        }
        public Tour(string M, string N   )
        {
            TourNo = M;
            TourName = N;
        }
        public Tour(string M,string N,string P)
        {
            TourNo = M;
            TourName=N;
            TourPlaceName = P;
        }


        class program {
            private static string Sylhet;
            private static string India;
            static void Main(string[] args)
            {
                Tour T1 = new Tour("TourNo:one");
                Tour T2 = new Tour("TourNo:two", Sylhet);
                Tour T3 = new Tour("TourNo:two", India,"klakata");
                Console.WriteLine("{0}", T1.TourNo);
                Console.WriteLine("{0} {1}", T2.TourNo, T2.TourName);
                Console.WriteLine("{0} {1} {2}", T3.TourNo, T3.TourName, T3.TourPlaceName);
                Console.ReadLine();
            }
        }
    }
}
