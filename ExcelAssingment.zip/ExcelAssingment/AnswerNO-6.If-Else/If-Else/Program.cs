﻿using System;
using System.Collections.Generic;

namespace If_Else
{
    public class Program
    {




        static void Main(string[] args)
        {
            int n1 = 10;
            int n2 = 30;
            int n3 = 40;
            int min;

            if (n1 < n2)
            {
                min = n1;
               // Console.WriteLine(min);
            }
            else
            {
                min = n2;
                Console.WriteLine(min);
            }



            if (min < n3)
            {
                min = n3;
                Console.WriteLine(min);
            }
            else
            {
                Console.WriteLine(min);
            }


        }
    }
}

