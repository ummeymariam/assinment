﻿using System;

namespace Forloop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 30;
            for (int i = 0; i <=5; i++)
            {
                    
                n += i;

                Console.WriteLine("Value of n: {0}", n);
            }
            Console.WriteLine("Value of n: {0}", n);
        }
    }
}
