﻿using System;
using System.Collections.Generic;
using System.Text;
using SSE.Models;

namespace SSE.Repositories.Interface
{
    public interface ICountryRepo
    {
        IEnumerable<Country> GetCountries();
        void SaveCountry(Country country);
    }
}
