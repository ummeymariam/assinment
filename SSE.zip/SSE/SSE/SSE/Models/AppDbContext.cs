﻿using Microsoft.EntityFrameworkCore;
using System;
using SSE.Models;


namespace SSE.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<CustomerAddress> CustomerAddresses { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Country>()
                .HasData(
                    new Country
                    {
                        Id = 1,
                        CountryName = "Bangladesh"
                    },
                    new Country
                    {
                        Id = 2,
                        CountryName = "UK"
                    }
                );
        }
    }


}

