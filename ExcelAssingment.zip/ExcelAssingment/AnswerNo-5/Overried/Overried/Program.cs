﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overried
{
    class Program
    {
        static void Main(string[] args)
        {
            BaseClass baseClassObj;
            baseClassObj = new BaseClass();
            Console.WriteLine("Base class method volume :" + baseClassObj.volume(-3, 8, 2));
            baseClassObj = new ChildClass();
            Console.WriteLine("Child class method volume :" + baseClassObj.volume(-2, 2, 2));
            Console.ReadLine();
        }
    }
}
