﻿using System;

namespace UML_Diagram
{

    public class Clinician
    {

        private string name;
        private string hospitalName;
      
       

        public Clinician()

        {
             bool login;

            if ( login = true)
            {
                string username = "R";
                string password = "P";
            }
        
        }


        public class Doctor
        {

            private string practiceNumber;
            private Clinician clinician;

            public Doctor()
            {

            }

            public void createPrescription(int patientNumber)
            {

            }
   
    
   
   
        public class Pharmacist
            {

                private string pharmacistNumber;
                private Clinician clinician;

                public Pharmacist()
                {

                }

                public void dispenseMedications(int prescriptionNumber)
                {

                }




                public class Program
                {
                    static void Main(string[] args)
                    {
                        Console.WriteLine("Hello World!");
                    }
                }
            }
        }
    }
}

