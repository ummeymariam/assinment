﻿using System;
using System.Collections.Generic;
using System.Text;
using SSE.Models;


namespace SSE.Repositories.Interface
{
    public interface ICustomerRepo
    {
        void SaveCustomerData(Customer customer);
        Customer GetCustomerById(int id);
        IEnumerable<Customer> GetCustomers();
        void DeleteCustomer(int id);
    }
}

