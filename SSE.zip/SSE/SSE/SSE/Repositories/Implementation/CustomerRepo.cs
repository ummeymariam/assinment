﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SSE.Repositories.Implementation; 
using SSE.Models;
using SSE.Repositories.Interface;

namespace SSE.Repositories.Implementation
{
    public class CustomerRepo : ICustomerRepo
    {
        private readonly IGenericRepo<Customer> _cusRepo;
        private readonly IGenericRepo<CustomerAddress> _addRepo;

        public CustomerRepo(IGenericRepo<Customer> cusRepo, IGenericRepo<CustomerAddress> addRepo)
        {
            _cusRepo = cusRepo;
            _addRepo = addRepo;
        }

        public void DeleteCustomer(int id)
        {
            _cusRepo.Delete(id);
            _cusRepo.Commit();
        }

        public Customer GetCustomerById(int id)
        {
            try
            {
                Customer customer = _cusRepo.FindByCondition(x => x.Id == id).FirstOrDefault();
                List<CustomerAddress> customerAddresses = _addRepo.FindByCondition(x => x.CustomerId == customer.Id).ToList();
                customer.CustomerAddresses = customerAddresses;
                return customer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Customer> GetCustomers()
        {
            try
            {
                return _cusRepo.FindAll();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void SaveCustomerData(Customer customer)
        {
            try
            {
                if (customer.Id > 0)
                {
                    List<CustomerAddress> needUpdated = new List<CustomerAddress>();
                    foreach (var item in customer.CustomerAddresses)
                    {
                        needUpdated.Add(item);
                    }
                    List<CustomerAddress> fr = CustomerAddressesToDelete(customer.CustomerAddresses, customer.Id);
                    foreach (var item in fr)
                    {
                        try
                        {
                            _addRepo.Delete(item.Id);
                        }
                        catch (Exception ex)
                        {

                            throw ex;
                        }
                    }
                    foreach (CustomerAddress item in needUpdated)
                    {
                        try
                        {
                            if (item.Id > 0)
                            {
                                _addRepo.Update(item);
                            }
                            else
                            {
                                item.CustomerId = customer.Id;
                                _addRepo.Create(item);
                            }
                        }
                        catch (Exception ex)
                        {

                            throw ex;
                        }
                    }
                    _addRepo.Commit();
                    if (customer.CustomerPhoto == null)
                    {
                        Customer c1 = _cusRepo.FindByCondition(x => x.Id == customer.Id).FirstOrDefault();
                        customer.CustomerPhoto = c1.CustomerPhoto;
                    }
                    customer.CustomerAddresses = null;
                    _cusRepo.Update(customer);
                }
                else
                {
                    _cusRepo.Create(customer);
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private List<CustomerAddress> CustomerAddressesToDelete(List<CustomerAddress> param, int cusId)
        {
            try
            {
                List<CustomerAddress> customerAddressesInDb = _addRepo.FindByCondition(y => y.CustomerId == cusId).ToList();
                var ids = customerAddressesInDb.Select(x => x.Id);
                var pIds = param.Select(x => x.Id);
                var dIds = ids.Except(pIds);
                var result = customerAddressesInDb.Where(x => dIds.Contains(x.Id));
                return result.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
