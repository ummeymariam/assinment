﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SSE.Models
{
    public class Country
    {
        public int Id { get; set; }
        [Column(TypeName = "NVARCHAR(50)")]
        public string CountryName { get; set; }
        //nev
        public List<Customer> Customers { get; set; }

    }
}
