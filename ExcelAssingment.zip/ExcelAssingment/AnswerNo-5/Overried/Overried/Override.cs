﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overried
{
    class BaseClass
    {
        public virtual int volume(int a, int b, int c)
        {

            return (a * b * c);
        }

    }
    class ChildClass : BaseClass
    {
        public override int volume(int a, int b, int c)
        {

            if (a <= 0 || b <= 0 || c <= 0)
            {
                Console.WriteLine("Values could not be less than zero or equals to zero");
                Console.WriteLine("Enter First value : ");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter secound value : ");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter third value : ");
                c = Convert.ToInt32(Console.ReadLine());
            }
            return (a * b * c);

        }

    }
   

}

