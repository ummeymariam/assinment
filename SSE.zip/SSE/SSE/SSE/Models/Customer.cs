﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SSE.Models
{
    public class Customer
    {
        public int Id { get; set; }
        [ForeignKey("Country")]
        public int CountryId { get; set; }
        [Column(TypeName = "NVARCHAR(100)")]
        public string CustomerName { get; set; }
        [Column(TypeName = "NVARCHAR(100)")]
        public string FatherName { get; set; }
        [Column(TypeName = "NVARCHAR(100)")]
        public string MotherName { get; set; }
        public int MeritalStatus { get; set; }
        [Column(TypeName = "VARBINARY(MAX)")]
        public byte[] CustomerPhoto { get; set; }

        //nev
        public Country Country { get; set; }
        public List<CustomerAddress> CustomerAddresses { get; set; }

    }
}
